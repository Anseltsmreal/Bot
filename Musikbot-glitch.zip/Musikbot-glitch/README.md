# Discord-Music-Bot
A Discord Music Bot made with ♥ by [Ahad#3257](https://www.itscruel.cf)

# How To Use?
It's very simple just follow the steps written below.

Run `setup.bat` to install all dependencies.

Enter your Bot's Token in `config.json` 

Run `start.bat`

Type `$help` to see list of commands.

# Features
・High Music Quality.

・Stage Channels Support.

・Supports Music from Spotify and YouTube.

・Easy to use.

・Hostable on [__**Heroku.**__](https://www.heroku.com)

・Hostable on [__**Replit.**__](https://replit.com/@V-UNIT/Music-Bot)
***

<p align="center"><img width="800px" src="https://media.discordapp.net/attachments/914513217659756585/981729339563454494/unknown.png"/></p>

***
# Note:
Use it but please give credits to author.

Skidding this code is not allowed if you see anyone taking credits of this script dm me on discord.

# Social Media:
[Instagram](https://www.instagram.com/ahadnoor._) ・
[Discord](https://discord.gg/Ncsc5pRNgf) ・
[Website](https://www.itscruel.cf/) 

# Discord: Ahad#3257
If you liked this music bot please don't forget to give it a star it would mean a lot.
***
[![Spotify](https://media.discordapp.net/attachments/914513217659756585/981731270516162560/unknown.png)](https://www.vivre.cf)

[![YouTube](https://media.discordapp.net/attachments/914513217659756585/981731158956060682/unknown-1.jpeg)](https://itscruel.cf/social-medias)

[![Ahad](https://media.discordapp.net/attachments/840846571326275609/995180079623700522/DEE8C6CD-F31C-4CB2-B852-EBF7FF8BF373.jpg)](https://www.itscruel.cf)

***
